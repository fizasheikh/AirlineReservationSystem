﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data ;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Try
{
    public partial class Booking : Form
    {
        Ticket ticket = new Ticket();
        public string a;
      
    
         public string trip;
         public string ticketclass;
         public string ticketprice;
         public string gate;
        public string flight;
     
        private OleDbConnection connection = new OleDbConnection();
        public Booking()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Dell\\Documents\\Database1.accdb";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // hiding booking window form and open smain window on clicking back button
            this.Hide();
            Form1 f = new Form1();
            f.ShowDialog();
        }
      
        // method to decide trip and send to db
        public void ftrip()
        {
            if (radioButton1.Checked)
            {
                trip = radioButton1.Text;
            }
            else if (radioButton2.Checked)
            {
                trip = radioButton2.Text;
            }
        }

        //method to decide class and send to db
        public void fclass()
        {
            if (radioButton3.Checked)
            {
                ticketclass = radioButton3.Text;
            }
            else if (radioButton4.Checked)
            {
                ticketclass = radioButton4.Text;
            }
        }

        //method to decide ticket price

        public string priceofticket()
        {
            if (radioButton1.Checked && radioButton4.Checked)
            {
                ticketprice = "20,000";
            }
            else if (radioButton1.Checked && radioButton3.Checked)
            {
                ticketprice = "25,000";
            }
            else if (radioButton2.Checked && radioButton4.Checked)
            {
                ticketprice = "40,000";
            }
            else if (radioButton2.Checked && radioButton3.Checked)
            {
                ticketprice = "50,000";
            }
            return ticketprice;


        }
       
        //method to generate gate label for ticket
        public string Gate()
        {
            if (radioButton1.Checked && radioButton4.Checked)
            {
                gate = "A";
            }
            else if (radioButton1.Checked && radioButton3.Checked)
            {
                gate = "B";
            }
            else if (radioButton2.Checked && radioButton4.Checked)
            {
                gate = "C";
            }
            else if (radioButton2.Checked && radioButton3.Checked)
            {
                gate = "D";
            }

            return gate;
        }

        //method to generate flight label for ticket
        public string Flight()
        {
            if (comboBox1.Text == "KARACHI")
            {
                flight = "KHI-01";
            }
            else if (comboBox1.Text == "LAHORE")
            {
                flight = "LHR-01";
            }
            else if (comboBox1.Text == "ISLAMABAD")
            {
                flight = "ISB-01";
            }
            else if (comboBox1.Text == "FAISLBAD")
            {
                flight = "FSB-01";
            }
            else if (comboBox1.Text == "DUBAI")
            {
                flight = "DXB-01";
            }
            return flight;
        }
     
       

          private void Booking_Load(object sender, EventArgs e)
          {

          }

          private void groupBox1_Enter(object sender, EventArgs e)
          {

          }

          private void textBox1_TextChanged(object sender, EventArgs e)
          {
             
              ticket.label6.Text = textBox1.Text;
             ticket.label25.Text = textBox1.Text;

          }

          private void radioButton3_CheckedChanged(object sender, EventArgs e)
          {
              if (radioButton3.Checked)
              {
                  ticket.label4.Text = radioButton3.Text + " Class";
              }
             
          }

          private void radioButton4_CheckedChanged(object sender, EventArgs e)
          {

              if (radioButton4.Checked)
              {
                  ticket.label4.Text = radioButton4.Text + " Class" ;
              }
          }

          private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
          {
              ticket.label29.Text = comboBox2.Text;
              ticket.label10.Text = comboBox2.Text;

          }

          private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
          {
              ticket.label8.Text = comboBox1.Text;
              ticket.label27.Text = comboBox1.Text;
          }
        
          private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
          {
          //    ticket.label13.Text = dateTimePicker1.Value.ToShortDateString();
              
            //  ticket.label33.Text = dateTimePicker1.Value.ToShortDateString(); 
          
          }


          private void button1_Click(object sender, EventArgs e)
          {
              // confirm button operation
              try
              {
                  connection.Open();
                  OleDbCommand command = new OleDbCommand();
                  command.Connection = connection;
                 
                  // arrival and departure cant be same

                  if (comboBox1.Text == comboBox2.Text)
                  {
                      MessageBox.Show("Select different destination");
                  }
                    else if(comboBox3.Text=="")
                  {
                      MessageBox.Show("Select Time!");

                    }

                  else if (comboBox1.Text== "" || comboBox2.Text== "")
                  {
                      MessageBox.Show("Select Place!");
                  }
                  else if (radioButton1.Checked || radioButton2.Checked)
                  {
                      if (radioButton3.Checked || radioButton4.Checked)
                      {
                          //ticket price printing
                          ftrip();
                          fclass();
                       string g=   Gate();
                         string f= Flight();
                   //      MessageBox.Show(f);
                          priceofticket();

                          ticket.label21.Text = ticketprice;
                          ticket.label37.Text = ticketprice;

                          ticket.label35.Text = comboBox3.Text;
                          ticket.label15.Text = comboBox3.Text;

                          ticket.label12.Text = f;
                          ticket.label31.Text = f;

                          ticket.label19.Text = g;

                          ticket.label13.Text = dateTimePicker1.Value.ToShortDateString();

                          ticket.label33.Text = dateTimePicker1.Value.ToShortDateString(); 

                          //database query and connection
                          command.CommandText = "INSERT INTO Table1(FirstName,LastName,FlyingFrom,FlyingTo,Date_,Trip,Class) Values ('" + textBox1.Text + "','" + textBox2.Text + "','" + comboBox2.Text + "','" + comboBox1.Text + "','" + dateTimePicker1.Value.ToShortDateString() + "','" + trip + "', '" + ticketclass + "')";
                          command.ExecuteNonQuery();

                          command.CommandText = "select SeatNo from Table1 where FirstName='" + textBox1.Text + "' and LastName='" + textBox2.Text + "' ";
                          a = command.ExecuteScalar().ToString();
                          command.ExecuteNonQuery();

                          ticket.label39.Text =  a;
                          ticket.label17.Text = a;
                          connection.Close();

                          this.Hide();
                       
                          ticket.ShowDialog();

                         
                      }
                      else
                      {
                          MessageBox.Show("Select Class!");
                      }
                  }
                  else
                  {
                      MessageBox.Show("Select Trip!");
                  }
                  connection.Close();
              }
              catch (Exception ex)
              {
                  MessageBox.Show("Error!" + ex);
              }
            




          }

          private void radioButton2_CheckedChanged(object sender, EventArgs e)
          {

          }

         

       
         
    }
}




