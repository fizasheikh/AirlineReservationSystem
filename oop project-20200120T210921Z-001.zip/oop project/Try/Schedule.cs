﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Try
{
    public partial class Schedule : Form
    {

        private OleDbConnection connection = new OleDbConnection();
        public Schedule()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Dell\\Documents\\Database1.accdb";

        }

        private void Schedule_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (comboBox1.Text == comboBox2.Text)
            {
                MessageBox.Show("Select different destination!");
            }

            else if (comboBox1.Text == "" || comboBox2.Text == "")
            {
                MessageBox.Show("Select place!");

            }
            else
            {

                if (comboBox1.Text != comboBox2.Text)
                {

                    try
                    {
                        connection.Open();
                        OleDbCommand command = new OleDbCommand();
                        command.Connection = connection;
                        string thedate = dateTimePicker1.Text;
                        string query = "select fdate,FlyingFrom,FlyingTo,FlightName,ftime from Table2 where fdate ='" + thedate + "'AND FlyingFrom = '" + comboBox1.Text + "'AND FlyingTo ='" + comboBox2.Text + "'";
                        command.CommandText = query;

                        OleDbDataAdapter da = new OleDbDataAdapter(command);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;

                        command.ExecuteNonQuery();
                        connection.Close();
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show("Error!" + ex);
                    }
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.ShowDialog();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    
    }
}
