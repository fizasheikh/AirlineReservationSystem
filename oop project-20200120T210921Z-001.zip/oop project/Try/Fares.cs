﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Try
{
    public partial class Fares : Form
    {
      
       
        public Fares()
        {
            InitializeComponent();
        }
       

        private void Fares_Load(object sender, EventArgs e)
        {

        }
     string price;

     

       private void label2_Click(object sender, EventArgs e)
       {

       }

       private void button1_Click(object sender, EventArgs e)
       {
           if (comboBox1.Text == comboBox2.Text)
           {
               MessageBox.Show("Select different destination!");
           }
           else if(comboBox1.Text == "" || comboBox2.Text == "")
            {
                MessageBox.Show("Select place!");

            }
           else if (radioButton1.Checked || radioButton2.Checked)
           {
               if (radioButton3.Checked || radioButton4.Checked)
               {
                  if(comboBox1.Text != comboBox2.Text)
                  {
                      if (radioButton1.Checked && radioButton4.Checked)
                   {
                       price = "20,000";
                   }
                   else if (radioButton1.Checked && radioButton3.Checked)
                   {
                       price = "25,000";
                   }
                   else if (radioButton2.Checked && radioButton4.Checked)
                   {
                       price = "40,000";
                   }
                   else if (radioButton2.Checked && radioButton3.Checked)
                   {
                       price = "50,000";
                   }
                   label1.Text = price;
                 }
               }
               else 
               { 
                   MessageBox.Show("Select Class!");
               }
           }
           else
           
           {
           MessageBox.Show("Select Trip!");
           }
       }

           
          

       private void button2_Click(object sender, EventArgs e)
       {
           this.Hide();
           Form1 f = new Form1();
           f.ShowDialog();
       }

       private void label1_Click(object sender, EventArgs e)
       {

       }

      
    }
}
