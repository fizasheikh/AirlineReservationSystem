﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Try
{
    public partial class Canceling : Form
    {
        public string check;
        private OleDbConnection connection = new OleDbConnection();
        public Canceling()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Dell\\Documents\\Database1.accdb";
        }

       
        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                if (textBox1.Text != "")
                {
                    connection.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = connection;
                    int sn = int.Parse(textBox1.Text);
                    string query = "select SeatNo FROM  Table1 WHERE SeatNo =  " + sn + "  ";

                    command.CommandText = query;

                    object a = null;
                    a = command.ExecuteScalar();

                    int abc = Convert.ToInt32(a);

                    if (sn == abc)
                    {

                        command.CommandText = "Delete * from Table1 where SeatNo = " + sn + "";
                        command.ExecuteNonQuery();
                        MessageBox.Show("Your Booking has been cancelled!");

                    }
                    else if (a == null)
                    {
                        MessageBox.Show("Invalid Seat no!");
                    }


                    connection.Close();

                }
                else
                { MessageBox.Show("Enter seat no!"); }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error!" + ex);
            }
        


        }

        private void Canceling_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
        }

       
    }
}
